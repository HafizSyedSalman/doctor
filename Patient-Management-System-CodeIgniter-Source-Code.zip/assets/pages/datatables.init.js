/*
  Template Name: Doctorist - Patient Management System
 Author: Lndinghub(Themesbrand)
 File: Datatable js
 */

$(document).ready(function() {
    $('.datatable-init').DataTable();
} );