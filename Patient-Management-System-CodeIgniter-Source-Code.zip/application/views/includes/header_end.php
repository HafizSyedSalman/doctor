        
        <!-- App css -->
        <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url(); ?>assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet" type="text/css" />

        <style>
            blockquote{
                margin: 0 0 20px;
                padding: 10px 20px;
                font-size: 17.5px;
                border-left: 5px solid #3f51b5!important;
                border: 1px solid rgba(120, 130, 140, .13); }
        </style>
    </head>

    <body>
<?php include_once('topbar.php'); ?>